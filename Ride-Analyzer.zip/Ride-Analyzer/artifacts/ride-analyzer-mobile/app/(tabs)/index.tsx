import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  AppState,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';

const STORAGE_KEY = 'ride-analyzer-mobile-rides-v1';
const ACTIVE_STORAGE_KEY = 'ride-analyzer-mobile-active-v1';
const MAX_PLAUSIBLE_SPEED_KMH = 220;

type WaitingPeriod = {
  id: string;
  startAt: string;
  endAt: string;
  durationSeconds: number;
};

type FuelEntry = {
  id: string;
  addedAt: string;
  litres: number;
  pricePerLitre: number;
};

type Ride = {
  id: string;
  label: string;
  date: string;
  startedAt: string;
  endedAt: string;
  distanceKm: number;
  fuelLitres: number;
  fuelCost: number;
  durationMinutes: number;
  trafficWaitMinutes: number;
  averageSpeedKmh: number;
  topSpeedKmh: number;
  waitingPeriods: WaitingPeriod[];
  fuelEntries: FuelEntry[];
};

type LiveStats = {
  elapsedSeconds: number;
  speedKmh: number | null;
  averageSpeedKmh: number;
  topSpeedKmh: number;
  distanceKm: number;
  waitingSeconds: number;
  waitingPeriods: WaitingPeriod[];
  fuelLitres: number;
  fuelCost: number;
};

type PositionSnapshot = {
  latitude: number;
  longitude: number;
  timestamp: number;
  wallTime: number;
  accuracy: number;
};

type ActiveSessionSnapshot = {
  label: string;
  startAt: string;
  savedAt: number;
  live: LiveStats;
  waitingPeriods: WaitingPeriod[];
  activeWaitSince: string | null;
  fuelEntries: FuelEntry[];
  distanceMetres: number;
  topSpeedKmh: number;
  lastSpeedKmh: number | null;
  lastPosition: PositionSnapshot | null;
};

type TrackingPhase = 'ready' | 'active' | 'summary';
type GpsState = 'unknown' | 'searching' | 'ready' | 'denied';

const emptyStats: LiveStats = {
  elapsedSeconds: 0,
  speedKmh: null,
  averageSpeedKmh: 0,
  topSpeedKmh: 0,
  distanceKm: 0,
  waitingSeconds: 0,
  waitingPeriods: [],
  fuelLitres: 0,
  fuelCost: 0,
};

const parseSafeDate = (value: unknown): Date | null => {
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
};

const safeNumber = (value: unknown, fallback = 0): number => {
  const num = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(num) ? num : fallback;
};

const todayString = () => new Date().toISOString().slice(0, 10);
const formatNumber = (value: number, digits = 1) =>
  Number.isFinite(value) ? value.toFixed(digits) : (0).toFixed(digits);
const formatDuration = (seconds: number) => {
  const safe = Number.isFinite(seconds) ? Math.max(0, Math.round(seconds)) : 0;
  const hours = Math.floor(safe / 3600);
  const minutes = Math.floor((safe % 3600) / 60);
  const remainingSeconds = safe % 60;
  return hours > 0
    ? `${hours}h ${String(minutes).padStart(2, '0')}m`
    : `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
};
const formatClock = (value: string) => {
  const date = parseSafeDate(value);
  if (!date) return '--:--';
  return date.toLocaleTimeString([], {
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
  });
};
const sumWaiting = (periods: WaitingPeriod[]) =>
  (Array.isArray(periods) ? periods : []).reduce(
    (total, period) => total + safeNumber(period?.durationSeconds, 0),
    0,
  );
const haversineMetres = (
  latitudeA: number,
  longitudeA: number,
  latitudeB: number,
  longitudeB: number,
) => {
  if (
    !Number.isFinite(latitudeA) ||
    !Number.isFinite(longitudeA) ||
    !Number.isFinite(latitudeB) ||
    !Number.isFinite(longitudeB)
  ) {
    return 0;
  }
  const earthRadius = 6371000;
  const latitudeDelta = ((latitudeB - latitudeA) * Math.PI) / 180;
  const longitudeDelta = ((longitudeB - longitudeA) * Math.PI) / 180;
  const a =
    Math.sin(latitudeDelta / 2) ** 2 +
    Math.cos((latitudeA * Math.PI) / 180) *
      Math.cos((latitudeB * Math.PI) / 180) *
      Math.sin(longitudeDelta / 2) ** 2;
  const clampedA = Math.min(1, Math.max(0, a));
  return earthRadius * 2 * Math.atan2(Math.sqrt(clampedA), Math.sqrt(1 - clampedA));
};

export default function TabOneScreen() {
  const [rides, setRides] = useState<Ride[]>([]);
  const [phase, setPhase] = useState<TrackingPhase>('ready');
  const [label, setLabel] = useState('');
  const [live, setLive] = useState<LiveStats>(emptyStats);
  const [summary, setSummary] = useState<Ride | null>(null);
  const [gpsState, setGpsState] = useState<GpsState>('unknown');
  const [activeWaitSince, setActiveWaitSince] = useState<string | null>(null);
  const [showFuelModal, setShowFuelModal] = useState(false);
  const [fuelLitresInput, setFuelLitresInput] = useState('');
  const [fuelPriceInput, setFuelPriceInput] = useState('');
  const [currentTime, setCurrentTime] = useState(Date.now());

  const startAtRef = useRef<string | null>(null);
  const subscriptionRef = useRef<Location.LocationSubscription | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastSpeedRef = useRef<number | null>(null);
  const lastGpsFixAtRef = useRef(0);
  const lastMovementAtRef = useRef(0);
  const waitStartRef = useRef<string | null>(null);
  const waitingPeriodsRef = useRef<WaitingPeriod[]>([]);
  const distanceMetresRef = useRef(0);
  const topSpeedRef = useRef(0);
  const fuelEntriesRef = useRef<FuelEntry[]>([]);
  const lastPositionRef = useRef<PositionSnapshot | null>(null);
  const liveRef = useRef<LiveStats>(emptyStats);

  useEffect(() => {
    liveRef.current = live;
  }, [live]);

  const setLiveStats = (next: LiveStats) => {
    liveRef.current = next;
    setLive(next);
  };

  const cleanupLocation = () => {
    if (subscriptionRef.current) {
      try {
        subscriptionRef.current.remove();
      } catch {
        // Ignore removal errors
      }
      subscriptionRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const persistActiveSession = async () => {
    const startDate = parseSafeDate(startAtRef.current);
    if (!startDate || !startAtRef.current) return;
    const now = Date.now();
    const elapsedSeconds = Math.max(0, Math.round((now - startDate.getTime()) / 1000));
    const waitStartDate = parseSafeDate(waitStartRef.current);
    const openWaitSeconds = waitStartDate
      ? Math.max(0, Math.round((now - waitStartDate.getTime()) / 1000))
      : 0;
    const distanceKm = distanceMetresRef.current / 1000;
    const snapshot: ActiveSessionSnapshot = {
      label,
      startAt: startAtRef.current,
      savedAt: now,
      live: {
        ...liveRef.current,
        elapsedSeconds,
        distanceKm,
        averageSpeedKmh: elapsedSeconds > 0 ? distanceKm / (elapsedSeconds / 3600) : 0,
        waitingPeriods: [...waitingPeriodsRef.current],
        waitingSeconds: sumWaiting(waitingPeriodsRef.current) + openWaitSeconds,
        fuelLitres: fuelEntriesRef.current.reduce((sum, item) => sum + item.litres, 0),
        fuelCost: fuelEntriesRef.current.reduce(
          (sum, item) => sum + item.litres * item.pricePerLitre,
          0,
        ),
      },
      waitingPeriods: [...waitingPeriodsRef.current],
      activeWaitSince: waitStartRef.current,
      fuelEntries: [...fuelEntriesRef.current],
      distanceMetres: distanceMetresRef.current,
      topSpeedKmh: topSpeedRef.current,
      lastSpeedKmh: lastSpeedRef.current,
      lastPosition: lastPositionRef.current,
    };
    try {
      await AsyncStorage.setItem(ACTIVE_STORAGE_KEY, JSON.stringify(snapshot));
    } catch {
      // Ignore storage write errors
    }
  };

  const handleLocationUpdate = (location: Location.LocationObject) => {
    if (!location || !location.coords) return;
    const { latitude, longitude, accuracy: rawAccuracy, speed: rawSpeed } = location.coords;
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return;

    const nowWall = Date.now();
    const posTimestamp =
      Number.isFinite(location.timestamp) && location.timestamp > 0
        ? location.timestamp
        : nowWall;
    const accuracy =
      rawAccuracy !== null && Number.isFinite(rawAccuracy) && rawAccuracy > 0
        ? rawAccuracy
        : 20;

    lastGpsFixAtRef.current = nowWall;
    setGpsState('ready');

    const previousSnapshot = lastPositionRef.current;
    if (previousSnapshot && accuracy > 150) {
      return;
    }

    const reportedSpeedKmh =
      rawSpeed !== null &&
      Number.isFinite(rawSpeed) &&
      rawSpeed >= 0 &&
      rawSpeed * 3.6 <= MAX_PLAUSIBLE_SPEED_KMH
        ? rawSpeed * 3.6
        : null;

    let computedSpeedKmh: number | null = reportedSpeedKmh;

    if (previousSnapshot) {
      const deltaMetres = haversineMetres(
        previousSnapshot.latitude,
        previousSnapshot.longitude,
        latitude,
        longitude,
      );
      const rawElapsed = (posTimestamp - previousSnapshot.timestamp) / 1000;
      const wallElapsed = (nowWall - previousSnapshot.wallTime) / 1000;
      const elapsed =
        Number.isFinite(rawElapsed) && rawElapsed > 0 && rawElapsed < 36000
          ? rawElapsed
          : Math.max(0, wallElapsed);

      const combinedAccuracy = Math.max(accuracy, previousSnapshot.accuracy);
      const minMoveMetres = Math.max(3, Math.min(combinedAccuracy * 0.35, 12));
      const isLikelyJitter =
        deltaMetres < minMoveMetres ||
        (reportedSpeedKmh !== null &&
          reportedSpeedKmh < 1.5 &&
          deltaMetres < Math.max(8, combinedAccuracy * 0.6));

      if (!isLikelyJitter && elapsed > 0.2) {
        const impliedSpeedKmh = (deltaMetres / elapsed) * 3.6;
        if (impliedSpeedKmh <= MAX_PLAUSIBLE_SPEED_KMH) {
          distanceMetresRef.current += Math.max(0, deltaMetres);
          lastMovementAtRef.current = nowWall;
          if (computedSpeedKmh === null && elapsed >= 0.8) {
            computedSpeedKmh = Math.max(0, impliedSpeedKmh);
          }
        }
      } else if (isLikelyJitter) {
        if (computedSpeedKmh === null || computedSpeedKmh < 1.5) {
          computedSpeedKmh = 0;
        }
      }
    } else {
      lastMovementAtRef.current = nowWall;
      if (computedSpeedKmh === null) {
        computedSpeedKmh = 0;
      }
    }

    if (computedSpeedKmh !== null) {
      if (computedSpeedKmh >= 3) {
        lastMovementAtRef.current = nowWall;
      }
      lastSpeedRef.current = computedSpeedKmh;
      topSpeedRef.current = Math.max(topSpeedRef.current, Math.max(0, computedSpeedKmh));
    }

    lastPositionRef.current = {
      latitude,
      longitude,
      timestamp: posTimestamp,
      wallTime: nowWall,
      accuracy,
    };

    const startDate = parseSafeDate(startAtRef.current);
    const elapsedSeconds = startDate
      ? Math.max(0, Math.round((nowWall - startDate.getTime()) / 1000))
      : liveRef.current.elapsedSeconds;
    const distanceKm = distanceMetresRef.current / 1000;

    setLiveStats({
      ...liveRef.current,
      elapsedSeconds,
      speedKmh: lastSpeedRef.current,
      averageSpeedKmh: elapsedSeconds > 0 ? distanceKm / (elapsedSeconds / 3600) : 0,
      topSpeedKmh: topSpeedRef.current,
      distanceKm,
    });
    void persistActiveSession();
  };

  const closeWaitingPeriod = (endedAt: string) => {
    const startedAt = waitStartRef.current;
    const startDate = parseSafeDate(startedAt);
    const endDate = parseSafeDate(endedAt);
    if (!startedAt || !startDate || !endDate) {
      waitStartRef.current = null;
      setActiveWaitSince(null);
      return;
    }
    const durationSeconds = Math.max(
      1,
      Math.round((endDate.getTime() - startDate.getTime()) / 1000),
    );
    const period: WaitingPeriod = {
      id: `wait-${Date.now()}`,
      startAt: startedAt,
      endAt: endedAt,
      durationSeconds,
    };
    waitingPeriodsRef.current = [...waitingPeriodsRef.current, period];
    waitStartRef.current = null;
    setActiveWaitSince(null);
    setLiveStats({
      ...liveRef.current,
      waitingPeriods: waitingPeriodsRef.current,
      waitingSeconds: sumWaiting(waitingPeriodsRef.current),
    });
  };

  const evaluateWaiting = () => {
    const startDate = parseSafeDate(startAtRef.current);
    if (!startDate) return;
    const now = new Date();
    const nowMs = now.getTime();
    const nowIso = now.toISOString();

    if (lastSpeedRef.current !== null && lastSpeedRef.current > 0) {
      const sinceLastMoveSec =
        lastMovementAtRef.current > 0 ? (nowMs - lastMovementAtRef.current) / 1000 : 0;
      const sinceLastFixSec =
        lastGpsFixAtRef.current > 0 ? (nowMs - lastGpsFixAtRef.current) / 1000 : 0;
      if (sinceLastMoveSec >= 4.5 || sinceLastFixSec >= 5) {
        lastSpeedRef.current = 0;
      }
    }

    const gpsSpeed = lastSpeedRef.current;
    const isWaiting = gpsSpeed !== null && gpsSpeed < 3;

    if (isWaiting && !waitStartRef.current) {
      waitStartRef.current = nowIso;
      setActiveWaitSince(nowIso);
    } else if (!isWaiting && waitStartRef.current) {
      closeWaitingPeriod(nowIso);
    }

    const waitStartDate = parseSafeDate(waitStartRef.current);
    const openWaitSeconds = waitStartDate
      ? Math.max(0, Math.round((nowMs - waitStartDate.getTime()) / 1000))
      : 0;
    const elapsedSeconds = Math.max(0, Math.round((nowMs - startDate.getTime()) / 1000));
    const distanceKm = distanceMetresRef.current / 1000;
    setLiveStats({
      ...liveRef.current,
      speedKmh: lastSpeedRef.current,
      elapsedSeconds,
      averageSpeedKmh: elapsedSeconds > 0 ? distanceKm / (elapsedSeconds / 3600) : 0,
      waitingSeconds: sumWaiting(waitingPeriodsRef.current) + openWaitSeconds,
    });
    void persistActiveSession();
  };

  const startLocationTracking = async () => {
    if (!startAtRef.current) return;
    cleanupLocation();
    setGpsState('searching');
    try {
      const servicesEnabled = await Location.hasServicesEnabledAsync();
      if (!servicesEnabled) {
        setGpsState('denied');
        return;
      }
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setGpsState('denied');
        return;
      }

      // Request background permission quietly on native if supported, without crashing if unavailable in Expo Go
      if (Platform.OS !== 'web') {
        try {
          await Location.requestBackgroundPermissionsAsync();
        } catch {
          // Foreground tracking remains active if background permission is unsupported in current client
        }
      }

      try {
        const initial = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });
        handleLocationUpdate(initial);
      } catch {
        // Continue to watchPositionAsync
      }

      subscriptionRef.current = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.BestForNavigation,
          timeInterval: 1000,
          distanceInterval: 0,
        },
        handleLocationUpdate,
      );
    } catch {
      // Fallback to balanced accuracy if BestForNavigation fails
      try {
        subscriptionRef.current = await Location.watchPositionAsync(
          {
            accuracy: Location.Accuracy.Balanced,
            timeInterval: 2000,
            distanceInterval: 1,
          },
          handleLocationUpdate,
        );
      } catch {
        setGpsState('denied');
      }
    }

    intervalRef.current = setInterval(evaluateWaiting, 1000);
  };

  useEffect(() => {
    let mounted = true;
    const hydrate = async () => {
      try {
        const savedRidesRaw = await AsyncStorage.getItem(STORAGE_KEY);
        if (savedRidesRaw && mounted) {
          const parsed = JSON.parse(savedRidesRaw);
          if (Array.isArray(parsed)) setRides(parsed);
        }
        const activeRaw = await AsyncStorage.getItem(ACTIVE_STORAGE_KEY);
        if (activeRaw && mounted) {
          const snapshot = JSON.parse(activeRaw) as ActiveSessionSnapshot;
          if (snapshot && parseSafeDate(snapshot.startAt)) {
            startAtRef.current = snapshot.startAt;
            waitStartRef.current = snapshot.activeWaitSince ?? null;
            waitingPeriodsRef.current = Array.isArray(snapshot.waitingPeriods)
              ? snapshot.waitingPeriods
              : [];
            distanceMetresRef.current = safeNumber(snapshot.distanceMetres, 0);
            topSpeedRef.current = safeNumber(snapshot.topSpeedKmh, 0);
            fuelEntriesRef.current = Array.isArray(snapshot.fuelEntries)
              ? snapshot.fuelEntries
              : [];
            lastSpeedRef.current = snapshot.lastSpeedKmh ?? null;
            lastPositionRef.current = snapshot.lastPosition ?? null;
            setLabel(snapshot.label ?? '');
            setActiveWaitSince(snapshot.activeWaitSince ?? null);
            setLiveStats(snapshot.live ?? emptyStats);
            setPhase('active');
            void startLocationTracking();
          }
        }
      } catch {
        // Ignore storage read errors
      }
    };
    void hydrate();
    return () => {
      mounted = false;
      cleanupLocation();
    };
  }, []);

  useEffect(() => {
    if (phase !== 'active') return;
    const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [phase]);

  useEffect(() => {
    const sub = AppState.addEventListener('change', (nextState) => {
      if (nextState === 'background' || nextState === 'inactive') {
        void persistActiveSession();
      } else if (nextState === 'active' && phase === 'active' && !subscriptionRef.current) {
        void startLocationTracking();
      }
    });
    return () => sub.remove();
  }, [phase]);

  const startRide = async () => {
    const now = Date.now();
    const startedAt = new Date(now).toISOString();
    startAtRef.current = startedAt;
    lastPositionRef.current = null;
    lastSpeedRef.current = null;
    lastGpsFixAtRef.current = 0;
    lastMovementAtRef.current = now;
    waitStartRef.current = null;
    waitingPeriodsRef.current = [];
    distanceMetresRef.current = 0;
    topSpeedRef.current = 0;
    fuelEntriesRef.current = [];
    setLiveStats(emptyStats);
    setSummary(null);
    setActiveWaitSince(null);
    setPhase('active');
    await startLocationTracking();
    await persistActiveSession();
  };

  const endRide = async () => {
    const startDate = parseSafeDate(startAtRef.current);
    if (!startDate || !startAtRef.current) return;
    const endedAt = new Date().toISOString();
    closeWaitingPeriod(endedAt);
    const finalPeriods = [...waitingPeriodsRef.current];
    const elapsedSeconds = Math.max(
      1,
      Math.round((new Date(endedAt).getTime() - startDate.getTime()) / 1000),
    );
    const distanceKm = distanceMetresRef.current / 1000;
    const fuelLitres = fuelEntriesRef.current.reduce((sum, item) => sum + item.litres, 0);
    const fuelCost = fuelEntriesRef.current.reduce(
      (sum, item) => sum + item.litres * item.pricePerLitre,
      0,
    );
    const completedRide: Ride = {
      id: `ride-${Date.now()}`,
      label: label.trim() || `Ride · ${todayString()}`,
      date: todayString(),
      startedAt: startAtRef.current,
      endedAt,
      distanceKm,
      fuelLitres,
      fuelCost,
      durationMinutes: elapsedSeconds / 60,
      trafficWaitMinutes: sumWaiting(finalPeriods) / 60,
      averageSpeedKmh: distanceKm / (elapsedSeconds / 3600),
      topSpeedKmh: topSpeedRef.current,
      waitingPeriods: finalPeriods,
      fuelEntries: [...fuelEntriesRef.current],
    };
    cleanupLocation();
    const updatedRides = [completedRide, ...rides];
    setRides(updatedRides);
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(updatedRides));
      await AsyncStorage.removeItem(ACTIVE_STORAGE_KEY);
    } catch {
      // Ignore storage errors
    }
    setSummary(completedRide);
    setPhase('summary');
    startAtRef.current = null;
    setActiveWaitSince(null);
  };

  const saveFuel = () => {
    const litres = Number(fuelLitresInput);
    if (!Number.isFinite(litres) || litres <= 0) {
      Alert.alert('Invalid fuel amount', 'Please enter a valid number of litres.');
      return;
    }
    const pricePerLitre = Number(fuelPriceInput) > 0 ? Number(fuelPriceInput) : 0;
    const entry: FuelEntry = {
      id: `fuel-${Date.now()}`,
      addedAt: new Date().toISOString(),
      litres,
      pricePerLitre,
    };
    fuelEntriesRef.current = [...fuelEntriesRef.current, entry];
    const fuelLitres = fuelEntriesRef.current.reduce((sum, item) => sum + item.litres, 0);
    const fuelCost = fuelEntriesRef.current.reduce(
      (sum, item) => sum + item.litres * item.pricePerLitre,
      0,
    );
    setLiveStats({ ...liveRef.current, fuelLitres, fuelCost });
    void persistActiveSession();
    setFuelLitresInput('');
    setFuelPriceInput('');
    setShowFuelModal(false);
  };

  const totalDistance = useMemo(
    () => rides.reduce((sum, item) => sum + safeNumber(item.distanceKm, 0), 0),
    [rides],
  );

  const activeStartDate = parseSafeDate(startAtRef.current);
  const displayedElapsed =
    phase === 'active' && activeStartDate
      ? Math.max(0, Math.round((currentTime - activeStartDate.getTime()) / 1000))
      : live.elapsedSeconds;

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <View style={styles.headerCard}>
        <Text style={styles.kicker}>
          {phase === 'active'
            ? 'RIDE IN PROGRESS'
            : phase === 'summary'
              ? 'AFTER THE DRIVE'
              : 'BEFORE THE DRIVE'}
        </Text>
        <Text style={styles.heroTitle}>
          {phase === 'active'
            ? 'Keep your eyes on the road.'
            : phase === 'summary'
              ? 'Every drive tells a story.'
              : 'Ready when you are.'}
        </Text>
        <Text style={styles.subtitle}>
          Total recorded: {formatNumber(totalDistance)} km across {rides.length}{' '}
          {rides.length === 1 ? 'ride' : 'rides'}
        </Text>
      </View>

      {phase === 'ready' && (
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Start a ride</Text>
          <Text style={styles.bodyText}>
            Enter an optional route label and start recording live speed, distance, and traffic pauses.
          </Text>
          <TextInput
            value={label}
            onChangeText={setLabel}
            placeholder="e.g. Home to work"
            placeholderTextColor="#8e9aa1"
            style={styles.input}
          />
          <Pressable style={styles.primaryButton} onPress={() => void startRide()}>
            <Text style={styles.primaryButtonText}>Start ride</Text>
          </Pressable>
        </View>
      )}

      {phase === 'active' && (
        <View style={styles.darkCard}>
          <View style={styles.rowBetween}>
            <Text style={styles.darkTitle}>{label.trim() || 'Untitled ride'}</Text>
            <Text style={styles.badge}>
              {gpsState === 'ready'
                ? 'GPS ON'
                : gpsState === 'denied'
                  ? 'GPS OFF'
                  : 'SEARCHING GPS…'}
            </Text>
          </View>

          <View style={styles.speedBox}>
            <Text style={styles.speedLabel}>CURRENT SPEED</Text>
            <Text style={styles.speedValue}>
              {live.speedKmh === null ? '—' : formatNumber(live.speedKmh, 0)}{' '}
              <Text style={styles.speedUnit}>km/h</Text>
            </Text>
            {gpsState === 'denied' && (
              <Text style={styles.warningText}>
                Location permission is disabled. Enable location access in system settings to record speed and distance.
              </Text>
            )}
          </View>

          <View style={styles.statsGrid}>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>AVG SPEED</Text>
              <Text style={styles.statValue}>{formatNumber(live.averageSpeedKmh)} km/h</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>TOP SPEED</Text>
              <Text style={styles.statValue}>{formatNumber(live.topSpeedKmh, 0)} km/h</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>ELAPSED</Text>
              <Text style={styles.statValue}>{formatDuration(displayedElapsed)}</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>DISTANCE</Text>
              <Text style={styles.statValue}>{formatNumber(live.distanceKm)} km</Text>
            </View>
          </View>

          <View style={styles.waitBox}>
            <Text style={styles.statLabel}>
              TRAFFIC WATCH · {formatDuration(live.waitingSeconds)}
            </Text>
            <Text style={styles.waitStatus}>
              {activeWaitSince
                ? `Waiting since ${formatClock(activeWaitSince)}`
                : 'Automatically logs pauses when speed is under 3 km/h'}
            </Text>
          </View>

          <View style={styles.actionRow}>
            <Pressable style={styles.secondaryButton} onPress={() => setShowFuelModal(true)}>
              <Text style={styles.secondaryButtonText}>
                + Fuel ({formatNumber(live.fuelLitres, 2)} L)
              </Text>
            </Pressable>
            <Pressable style={styles.primaryButton} onPress={() => void endRide()}>
              <Text style={styles.primaryButtonText}>End ride</Text>
            </Pressable>
          </View>
        </View>
      )}

      {phase === 'summary' && summary && (
        <View style={styles.darkCard}>
          <Text style={styles.kicker}>RIDE COMPLETE</Text>
          <Text style={styles.darkTitle}>{summary.label}</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>DISTANCE</Text>
              <Text style={styles.statValue}>{formatNumber(summary.distanceKm)} km</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>AVG SPEED</Text>
              <Text style={styles.statValue}>{formatNumber(summary.averageSpeedKmh)} km/h</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>TOP SPEED</Text>
              <Text style={styles.statValue}>{formatNumber(summary.topSpeedKmh, 0)} km/h</Text>
            </View>
            <View style={styles.statCell}>
              <Text style={styles.statLabel}>WAITING</Text>
              <Text style={styles.statValue}>
                {formatDuration(summary.trafficWaitMinutes * 60)}
              </Text>
            </View>
          </View>
          <Pressable
            style={styles.primaryButton}
            onPress={() => {
              setSummary(null);
              setLabel('');
              setLiveStats(emptyStats);
              setPhase('ready');
            }}
          >
            <Text style={styles.primaryButtonText}>Start another ride</Text>
          </Pressable>
        </View>
      )}

      <Modal visible={showFuelModal} transparent animationType="slide">
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Text style={styles.sectionTitle}>Add fuel</Text>
            <TextInput
              value={fuelLitresInput}
              onChangeText={setFuelLitresInput}
              keyboardType="decimal-pad"
              placeholder="Litres (e.g. 12.5)"
              placeholderTextColor="#8e9aa1"
              style={styles.input}
            />
            <TextInput
              value={fuelPriceInput}
              onChangeText={setFuelPriceInput}
              keyboardType="decimal-pad"
              placeholder="Price per litre (optional)"
              placeholderTextColor="#8e9aa1"
              style={styles.input}
            />
            <View style={styles.actionRow}>
              <Pressable
                style={styles.secondaryButton}
                onPress={() => setShowFuelModal(false)}
              >
                <Text style={styles.secondaryButtonText}>Cancel</Text>
              </Pressable>
              <Pressable style={styles.primaryButton} onPress={saveFuel}>
                <Text style={styles.primaryButtonText}>Save fuel</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#f1ede4',
  },
  content: {
    padding: 20,
    paddingBottom: 100,
    gap: 16,
  },
  headerCard: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd6c9',
  },
  kicker: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1.4,
    color: '#db6742',
    marginBottom: 6,
  },
  heroTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#222a39',
  },
  subtitle: {
    marginTop: 6,
    fontSize: 13,
    color: '#59616b',
  },
  card: {
    backgroundColor: '#faf7ef',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: '#ded7ca',
    gap: 12,
  },
  darkCard: {
    backgroundColor: '#283344',
    borderRadius: 20,
    padding: 20,
    gap: 16,
  },
  rowBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#222a39',
  },
  darkTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#f7f3ea',
  },
  badge: {
    fontSize: 11,
    fontWeight: '700',
    color: '#c8d796',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#baca88',
  },
  bodyText: {
    fontSize: 14,
    color: '#59616b',
    lineHeight: 20,
  },
  input: {
    height: 48,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#d7cec0',
    backgroundColor: '#fffdf8',
    paddingHorizontal: 14,
    fontSize: 15,
    color: '#222a39',
  },
  primaryButton: {
    backgroundColor: '#e66d43',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  primaryButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#222a39',
  },
  secondaryButton: {
    borderWidth: 1,
    borderColor: '#baca88',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  secondaryButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#d0dc9d',
  },
  speedBox: {
    backgroundColor: '#202a38',
    borderRadius: 16,
    padding: 18,
  },
  speedLabel: {
    fontSize: 11,
    fontWeight: '700',
    color: '#89959c',
    letterSpacing: 1.2,
  },
  speedValue: {
    fontSize: 48,
    fontWeight: '700',
    color: '#f6bd80',
    marginTop: 6,
  },
  speedUnit: {
    fontSize: 16,
    fontWeight: '400',
    color: '#aab4b5',
  },
  warningText: {
    marginTop: 10,
    fontSize: 12,
    color: '#f6bd80',
    lineHeight: 18,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  statCell: {
    backgroundColor: '#202a38',
    borderRadius: 14,
    padding: 14,
    minWidth: '47%',
    flex: 1,
  },
  statLabel: {
    fontSize: 10,
    fontWeight: '700',
    color: '#89959c',
    letterSpacing: 1,
  },
  statValue: {
    fontSize: 18,
    fontWeight: '700',
    color: '#f7f3ea',
    marginTop: 6,
  },
  waitBox: {
    backgroundColor: '#202a38',
    borderRadius: 14,
    padding: 14,
  },
  waitStatus: {
    fontSize: 13,
    color: '#dce1df',
    marginTop: 6,
  },
  actionRow: {
    flexDirection: 'row',
    gap: 10,
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(28,36,48,0.6)',
    justifyContent: 'center',
    padding: 20,
  },
  modalCard: {
    backgroundColor: '#faf7ef',
    borderRadius: 20,
    padding: 20,
    gap: 12,
  },
});
